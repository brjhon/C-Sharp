﻿Console.WriteLine("Exemplo com 'else-if': ");

Console.Write("Digite um número de 1 a 4: ");
int numero = Convert.ToInt32(Console.ReadLine());

if (numero == 1)
{
    Console.WriteLine("Você escolheu: Bardo.");
}

else if (numero == 2)
{
    Console.WriteLine("Você escolheu: Arqueiro");
}

else if (numero == 3)
{
    Console.WriteLine("Você escolheu: Guerreiro");
}

else if (numero == 4)
{
    Console.WriteLine("Você escolheu: Mago");
}

else
{
    Console.WriteLine("Número invalido");
}

// Mantém a janela do console aberta
Console.ReadKey();
