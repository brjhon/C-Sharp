﻿//for (int i = 1; i <= 20; i++)
//{
//    if (i % 2 == 0)
//    {
//        Console.WriteLine(i);
//    }   
//}


// Solicita ao usuário um número inteiro N
// Console.WriteLine("Digite um número inteiro N:");
//int n = Convert.ToInt32(Console.ReadLine());
//int soma = 0;

// Loop para somar todos os números de 1 a N
// for (int i = 1; i <= n; i++)
// {
//  soma += i;
// }

// Exibe o resultado da soma
//Console.WriteLine($"A soma dos números de 1 a {n} é: {soma}");

Console.WriteLine("Digite um número inteiro positivo:");

// Lê a entrada do usuário e tenta converter para um inteiro
if (int.TryParse(Console.ReadLine(), out int N))
{
    // Verifica se o número é positivo
    if (N < 0)
    {
        Console.WriteLine("Por favor, digite um número inteiro positivo.");
        return;
    }

    // Inicializa a variável para armazenar o fatorial
    long fatorial = 1;

    // Loop para calcular o fatorial
    for (int i = 1; i <= N; i++)
    {
        fatorial *= i;
    }

    // Exibe o resultado do fatorial
    Console.WriteLine($"O fatorial de {N} é: {fatorial}");
}

