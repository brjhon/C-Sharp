﻿

List<(string Nome, double Peso)> atletas = new List<(string, double)>();

while (true)
{
    Console.Write("Digite o nome do atleta (ou 'sair' para terminar): ");
    string nome = Console.ReadLine();

    if (nome.ToLower() == "sair")
    {
        break;
    }

    double peso;
    while (true)
    {
        Console.Write($"Digite quantos quilos {nome} levantou: ");
        if (double.TryParse(Console.ReadLine(), out peso))
        {
            break;
        }
        else
        {
            Console.WriteLine("Por favor, digite um número válido para o peso.");
        }
    }

    atletas.Add((nome, peso));
}

if (atletas.Count == 0)
{
    Console.WriteLine("Nenhum atleta foi registrado.");
    return;
}

// Ordena a lista em ordem decrescente pelo peso
var atletasOrdenados = atletas.OrderByDescending(a => a.Peso).ToList();
if (atletasOrdenados.Count > 0)
{
    Console.WriteLine($"\nO atleta que ficou com o ouro é {atletasOrdenados[0].Nome} com {atletasOrdenados[0].Peso} quilos levantados!");
}
if (atletasOrdenados.Count > 1)
{
    Console.WriteLine($"O atleta que ficou com a prata é {atletasOrdenados[1].Nome} com {atletasOrdenados[1].Peso} quilos levantados!");
}
if (atletasOrdenados.Count > 2)
{
    Console.WriteLine($"O atleta que ficou com o bronze é {atletasOrdenados[2].Nome} com {atletasOrdenados[2].Peso} quilos levantados!");
}
