﻿using System;
using System.Collections.Generic;

class Program
{
    // Frequência da nota A4
    const double A4_Frequency = 440.0;
    // Intervalos em semitons de cada nota a partir de A4
    static readonly Dictionary<string, int> NoteOffsets = new Dictionary<string, int>
    {
        { "C", -9 }, { "C#", -8 }, { "Db", -8 },
        { "D", -7 }, { "D#", -6 }, { "Eb", -6 },
        { "E", -5 }, { "F", -4 }, { "F#", -3 }, { "Gb", -3 },
        { "G", -2 }, { "G#", -1 }, { "Ab", -1 },
        { "A", 0 }, { "A#", 1 }, { "Bb", 1 },
        { "B", 2 }
    };

    static void Main()
    {
        Console.WriteLine("Digite a nota musical (ex: A, C#, Db, etc.):");
        string inputNote = Console.ReadLine().ToUpper();

        Console.WriteLine("Digite a oitava (ex: 4 para A4):");
        if (!int.TryParse(Console.ReadLine(), out int octave))
        {
            Console.WriteLine("Oitava inválida.");
            return;
        }

        if (NoteOffsets.TryGetValue(inputNote, out int noteOffset))
        {
            double frequency = A4_Frequency * Math.Pow(2, (noteOffset + (octave - 4) * 12) / 12.0);
            Console.WriteLine($"A frequência da nota {inputNote}{octave} é: {frequency:F2} Hz");
        }
        else
        {
            Console.WriteLine("Nota inválida.");
        }
    }
}
