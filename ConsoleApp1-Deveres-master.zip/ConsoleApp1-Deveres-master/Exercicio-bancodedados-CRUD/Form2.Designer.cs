﻿namespace Exercicio_bancodedados_CRUD
{
    partial class Cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            Nome = new TextBox();
            Email = new TextBox();
            IDADE = new TextBox();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            panel1 = new Panel();
            label2 = new Label();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlDark;
            button1.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            button1.Location = new Point(322, 379);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(154, 38);
            button1.TabIndex = 0;
            button1.Text = "CADASTRAR";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Nome
            // 
            Nome.Location = new Point(241, 153);
            Nome.Margin = new Padding(3, 4, 3, 4);
            Nome.Name = "Nome";
            Nome.Size = new Size(411, 27);
            Nome.TabIndex = 1;
            Nome.TextChanged += Nome_TextChanged;
            // 
            // Email
            // 
            Email.Location = new Point(155, 207);
            Email.Margin = new Padding(3, 4, 3, 4);
            Email.Name = "Email";
            Email.Size = new Size(357, 27);
            Email.TabIndex = 2;
            Email.TextChanged += Email_TextChanged;
            // 
            // IDADE
            // 
            IDADE.Location = new Point(241, 259);
            IDADE.Margin = new Padding(3, 4, 3, 4);
            IDADE.Name = "IDADE";
            IDADE.Size = new Size(411, 27);
            IDADE.TabIndex = 3;
            IDADE.TextChanged += textBox3_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label1.Location = new Point(322, 25);
            label1.Name = "label1";
            label1.Size = new Size(154, 42);
            label1.TabIndex = 7;
            label1.Text = "CADASTRO DE \r\nBANCO DE DADOS  ";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label3.Location = new Point(155, 262);
            label3.Name = "label3";
            label3.Size = new Size(52, 21);
            label3.TabIndex = 9;
            label3.Text = "Idade";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label4.Location = new Point(542, 210);
            label4.Name = "label4";
            label4.Size = new Size(48, 21);
            label4.TabIndex = 10;
            label4.Text = "Email";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label5.Location = new Point(155, 150);
            label5.Name = "label5";
            label5.Size = new Size(55, 21);
            label5.TabIndex = 11;
            label5.Text = "Nome";
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDark;
            panel1.Location = new Point(106, 126);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(604, 232);
            panel1.TabIndex = 12;
            panel1.Paint += panel1_Paint;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point);
            label2.Location = new Point(542, 305);
            label2.Name = "label2";
            label2.Size = new Size(66, 21);
            label2.TabIndex = 14;
            label2.Text = "Salarios";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(155, 303);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(357, 27);
            textBox1.TabIndex = 13;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // Cadastro
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(831, 460);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(IDADE);
            Controls.Add(Email);
            Controls.Add(Nome);
            Controls.Add(button1);
            Controls.Add(panel1);
            Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Cadastro";
            Text = "Form2";
            Load += Cadastro_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox Nome;
        private TextBox Email;
        private TextBox IDADE;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Panel panel1;
        private Label label2;
        private TextBox textBox1;
    }
}