﻿using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Ocsp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Exercicio_bancodedados_CRUD
{
    public partial class Form4 : Form
    {
        private string UsuarioID;
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Verifica se um usuário foi selecionado
            if (string.IsNullOrEmpty(UsuarioID))
            {
                MessageBox.Show("Selecione um usuário na lista.");
                return;
            }

            // Atualiza os dados do usuário no banco de dados
            AtualizarUsuario(
                UsuarioID,
                textBox1.Text,  // Nome
                textBox2.Text,  // Email
                textBox3.Text,  // Idade
                textBox4.Text,   // Salário
                comboBox1.Text // Status
            );

            // Atualiza a lista de clientes
            ClienteHelper.CarregarClientes(listViewClientes);
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            listViewClientes.View = View.Details;
            listViewClientes.Columns.Add("ID", 50, HorizontalAlignment.Left);
            listViewClientes.Columns.Add("Nome", 150, HorizontalAlignment.Left);
            listViewClientes.Columns.Add("Email", 200, HorizontalAlignment.Left);
            listViewClientes.Columns.Add("Idade", 200, HorizontalAlignment.Left);
            listViewClientes.Columns.Add("Salario", 200, HorizontalAlignment.Left);
            listViewClientes.Columns.Add("Status", 200, HorizontalAlignment.Left);
            listViewClientes.Columns.Add("DataCriacao", 200, HorizontalAlignment.Left);

            listViewClientes.FullRowSelect = true; // Ativa a seleção da linha toda
            listViewClientes.GridLines = true; // Adiciona linhas de grade para melhor visualização
                                               // Carrega os usuarioss na ListView

            ClienteHelper.CarregarClientes(listViewClientes);
            comboBox1.Items.Add("Ativo");
            comboBox1.Items.Add("Inativo");
        }

        private void AtualizarUsuario(string UsuarioID, string nome, string email, string idade, string salario, string status)
        {
            string strConexao = "server=localhost;uid=root;database=bancodedados1";
            MySqlConnection conexao = new MySqlConnection(strConexao);

            try
            {
                conexao.Open();

                // Query para atualizar os dados na tabela 'usuarios' (exceto Salário)
                string queryAtualizarUsuario = @"
                UPDATE usuario SET 
                 Nome = @Nome, 
                 Email = @Email, 
                 Idade = @Idade, 
                 Status = @Status 
                 WHERE UsuarioID = @UsuarioID";

                MySqlCommand cmdAtualizarUsuario = new MySqlCommand(queryAtualizarUsuario, conexao);
                cmdAtualizarUsuario.Parameters.AddWithValue("@Nome", nome);
                cmdAtualizarUsuario.Parameters.AddWithValue("@Email", email);
                cmdAtualizarUsuario.Parameters.AddWithValue("@Idade", idade);
                cmdAtualizarUsuario.Parameters.AddWithValue("@Status", status);
                cmdAtualizarUsuario.Parameters.AddWithValue("@UsuarioID", UsuarioID);

                cmdAtualizarUsuario.ExecuteNonQuery();

                // Atualiza o Salário na tabela 'usuarioperfil'
                string queryAtualizarSalario = @"
                UPDATE usuarioperfil SET 
                salario = @Salario 
                WHERE PerfilID = @UsuarioID";  // Assumindo que PerfilID é o mesmo que UsuarioID

                MySqlCommand cmdAtualizarSalario = new MySqlCommand(queryAtualizarSalario, conexao);
                cmdAtualizarSalario.Parameters.AddWithValue("@Salario", salario);
                cmdAtualizarSalario.Parameters.AddWithValue("@UsuarioID", UsuarioID);

                cmdAtualizarSalario.ExecuteNonQuery();

                MessageBox.Show("Dados atualizados com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao atualizar o usuário: {ex.Message}");
            }
            finally
            {
                conexao.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Verifica se há algum item selecionado
            if (listViewClientes.SelectedItems.Count > 0)
            {
                // Pega o item selecionado
                ListViewItem itemSelecionado = listViewClientes.SelectedItems[0];

                // Preenche os campos de texto e o ComboBox com os dados do item selecionado
                UsuarioID = itemSelecionado.SubItems[0].Text;  // Armazena o ID do usuário
                textBox1.Text = itemSelecionado.SubItems[1].Text;  // Nome
                textBox4.Text = itemSelecionado.SubItems[4].Text;  // Email
                textBox3.Text = itemSelecionado.SubItems[3].Text;  // Idade
                textBox2.Text = itemSelecionado.SubItems[2].Text;  // Salário
                comboBox1.Text = itemSelecionado.SubItems[5].Text;  // Status
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
