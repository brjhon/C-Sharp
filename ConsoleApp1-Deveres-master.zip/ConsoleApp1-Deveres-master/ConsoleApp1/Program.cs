﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

//Exemplo de declaração de variaveis
int numero = 3;//Declaração de uma variavel inteira
int numero2 = 2;
int number = numero + numero2;
string mensagem = "Este é um exemplo de estrutura básica.";//Declaração de uma variavel de string

//Exibindo valores no console 
Console.WriteLine("o número é: " +numero + "+" + numero2 + "é: " + number);
Console.WriteLine(mensagem);

//Man´tém a janela do console aberta até que uma tecla seja prenssionada 
Console.ReadKey();
