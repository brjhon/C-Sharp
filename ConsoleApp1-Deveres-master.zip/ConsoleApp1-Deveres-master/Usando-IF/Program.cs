﻿Console.WriteLine("Exemplo com 'if':");

Console.Write("Digite um número: ");
int numero = Convert.ToInt32(Console.ReadLine());

if (numero > 70)
{
   Console.WriteLine("Financiamento Aprovado");
}
else 
{ 
   Console.WriteLine("Financiamento Reprovado"); 
}

Console.ReadKey();


Console.ReadKey();
