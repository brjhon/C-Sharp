﻿while (true)
{
    Console.Write("Digite um número para ver a tabuada(ou 'sair' para encerrar): ");
    string entrada = Console.ReadLine();

    // Verifica se o usúario deseja sair

    if (entrada.Trim().ToLower() == "sair")
    {
        break;
    }

    //Tenta converter a entrada para número inteiro
    if (int.TryParse(entrada, out int numero))
    {
        ExibirTabuada(numero);
    }

    else
    {
        //Se a entrada não for um número válido, exibe uma mensagem de erro
        Console.WriteLine("Por favor inserir um número válido.");
    }
}

/// <summary>
/// Exibe a tabuada do número fornecido.
/// </summary>
/// <param name="numero">O número para o qual a tabuada será exibida.</param>

static void ExibirTabuada(int numero)
{
    Console.WriteLine($"\nTabuada do {numero}:");
    for (int i = 1; i <= 10; i++)
    {
        int resultado = numero * i;
        Console.WriteLine($"{numero} x {i} = {resultado}");
    }
    Console.WriteLine(); // Linha em branco para separar as tabuadas
}