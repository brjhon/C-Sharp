﻿
// Solicita ao usuário que insira um número
Console.Write("Digite um número: ");
double numero = Convert.ToDouble(Console.ReadLine());

// Lê a entrada do usuário e tenta converter para double
if (!double.TryParse(Console.ReadLine(), out numero))
{
    Console.WriteLine("Entrada inválida. Por favor, insira um número válido.");
    return;
}

double resultado;

// Verifica se o número é divisível por 3
if (numero % 3 == 0)
{
    resultado = numero * 5;
    Console.WriteLine($"O número é divisível por 3. O quíntuplo do valor é: {resultado}");
}

else
{
    resultado = numero * 3;
    Console.WriteLine($"O número não é divisível por 3. O triplo do valor é: {resultado}");
}

// Mantém a janela do console aberta até que uma tecla seja pressionada
Console.ReadKey();

