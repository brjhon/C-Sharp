using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Aula_2_Front_end.Pages
{
    public class ShoppModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
