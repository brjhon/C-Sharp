﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static System.Net.Mime.MediaTypeNames;

public class IndexModel : PageModel
{
    public List<Imagem> Imagens { get; set; }

    public void OnGet()
    {
        // Simulação de uma galeria de imagens
        Imagens = new List<Imagem>
        {
            new Imagem { Url = "/Imagens/logo.png", Descricao = "Imagem 1" },
            new Imagem { Url = "/Imagens/never.jpg", Descricao = "Imagem 2" }

        };
    }
}

public class Imagem
{
    public string Url { get; set; }
    public string Descricao { get; set; }
}