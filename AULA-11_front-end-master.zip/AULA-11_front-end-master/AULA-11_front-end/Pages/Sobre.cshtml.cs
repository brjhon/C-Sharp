using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AULA_11_front_end.Pages
{
    public class SobreModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
